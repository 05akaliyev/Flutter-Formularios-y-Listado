package app.adi.flutter_forms_listing

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
