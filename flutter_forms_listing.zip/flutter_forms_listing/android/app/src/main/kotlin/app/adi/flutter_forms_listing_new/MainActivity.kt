package app.adi.flutter_forms_listing_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
