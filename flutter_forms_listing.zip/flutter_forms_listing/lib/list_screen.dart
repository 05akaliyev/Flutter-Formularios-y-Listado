import 'package:flutter/material.dart';
import 'city_details_screen.dart';

class ListScreen extends StatelessWidget {
  final String username;

  ListScreen({required this.username});

  final List<Map<String, String>> cities = [
    {'name': 'New Delhi', 'description': 'Capital de la India...'},
    {'name': 'Paris', 'description': 'Capital de Francia...'},
    {'name': 'Tokyo', 'description': 'Capital de Japón...'},
    {'name': 'Astana', 'description': 'Capital de Kazakhstan...'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('¡Hola $username!')),
      body: ListView.builder(
        itemCount: cities.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Hero(
              tag: cities[index]['name']!,
              child: CircleAvatar(
                child: Text(cities[index]['name']![0]),
              ),
            ),
            title: Text(cities[index]['name']!),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => CityDetailsScreen(
                    cityName: cities[index]['name']!,
                    cityDescription: cities[index]['description']!,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
