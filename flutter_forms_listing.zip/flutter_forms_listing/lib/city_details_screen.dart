import 'package:flutter/material.dart';

class CityDetailsScreen extends StatelessWidget {
  final String cityName;
  final String cityDescription;

  CityDetailsScreen({required this.cityName, required this.cityDescription});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(cityName)),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Hero(
            tag: cityName,
            child: Container(
              width: double.infinity,
              height: 200,
              color: Colors.blue,
              child: Center(
                child: Text(
                  cityName,
                  style: TextStyle(fontSize: 36, color: Colors.white),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              cityDescription,
              style: TextStyle(fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }
}
